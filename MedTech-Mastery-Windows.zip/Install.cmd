@echo off
title MedTech Mastery - Install
echo.
echo   Installing MedTech Mastery...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
