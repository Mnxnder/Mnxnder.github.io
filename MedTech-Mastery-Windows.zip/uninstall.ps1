# MedTech Mastery - uninstaller. Removes the shortcuts and the installed copy.
# Your study progress lives in the browser, not in these files; to keep it,
# use "Save progress file" in the app (Method tab) before uninstalling.
param([string]$InstallDir = (Join-Path $env:LOCALAPPDATA 'MedTechMastery'))
$appName = 'MedTech Mastery'
foreach ($p in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $lnk = Join-Path $p "$appName.lnk"
  if (Test-Path $lnk) { Remove-Item $lnk -Force }
}
if (Test-Path $InstallDir) {
  Set-Location $env:TEMP
  Remove-Item $InstallDir -Recurse -Force
}
Write-Host ''
Write-Host "  $appName has been removed." -ForegroundColor Green
Write-Host ''
