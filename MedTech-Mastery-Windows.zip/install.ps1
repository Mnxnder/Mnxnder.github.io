# MedTech Mastery - installer (Windows 10/11)
# Copies the app into your user folder and adds Desktop + Start Menu shortcuts
# that open it in its own window (Edge or Chrome "app mode"). No admin rights,
# nothing downloaded, nothing sent anywhere.
param(
  [string]$InstallDir = (Join-Path $env:LOCALAPPDATA 'MedTechMastery'),
  [string]$ShortcutDir = ''
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$appName = 'MedTech Mastery'
$html = 'MedTech-Mastery.html'

try {
  foreach ($f in @($html, 'app.ico')) {
    if (-not (Test-Path (Join-Path $here $f))) { throw "Missing $f - extract the whole zip first, then run Install again." }
  }

  New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
  foreach ($f in @($html, 'app.ico', 'uninstall.ps1', 'Uninstall.cmd')) {
    $src = Join-Path $here $f
    if (Test-Path $src) {
      Copy-Item $src (Join-Path $InstallDir $f) -Force
      Unblock-File (Join-Path $InstallDir $f) -ErrorAction SilentlyContinue
    }
  }
  $target = Join-Path $InstallDir $html
  $url = ([System.Uri]$target).AbsoluteUri

  # Prefer Edge (built into Windows), then Chrome. Both support --app windows.
  $candidates = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
  )
  $browser = $candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1

  $ws = New-Object -ComObject WScript.Shell
  function New-AppShortcut([string]$path) {
    $s = $ws.CreateShortcut($path)
    if ($browser) {
      $s.TargetPath = $browser
      $s.Arguments = "--app=`"$url`""
    } else {
      $s.TargetPath = $target   # no Edge/Chrome: open in the default browser
    }
    $s.WorkingDirectory = $InstallDir
    $s.IconLocation = (Join-Path $InstallDir 'app.ico') + ',0'
    $s.Description = 'Clinical Chemistry, Microscopy and Parasitology study game'
    $s.Save()
  }

  if ($ShortcutDir) {
    New-Item -ItemType Directory -Force -Path $ShortcutDir | Out-Null
    $places = @($ShortcutDir)
  } else {
    $places = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))
  }
  foreach ($p in $places) { New-AppShortcut (Join-Path $p "$appName.lnk") }

  Write-Host ''
  Write-Host "  $appName is installed." -ForegroundColor Green
  Write-Host "  Open it from the Desktop icon or the Start Menu ('$appName')."
  if ($browser) { Write-Host "  It opens in its own window using: $(Split-Path -Leaf $browser)" }
  else { Write-Host '  Edge/Chrome not found - it will open in your default browser.' -ForegroundColor Yellow }
  Write-Host "  App files: $InstallDir"
  Write-Host ''
  Write-Host '  Moving progress from your other laptop? In the app: Method tab ->'
  Write-Host '  "Studying on another laptop" -> Load progress file.'
  Write-Host ''
} catch {
  Write-Host ''
  Write-Host "  Install failed: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host '  Fallback: just double-click MedTech-Mastery.html - the app works on its own.'
  Write-Host ''
  exit 1
}
