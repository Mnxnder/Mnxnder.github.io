@echo off
title MedTech Mastery - Uninstall
copy /y "%~dp0uninstall.ps1" "%TEMP%\medtech-uninstall.ps1" >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\medtech-uninstall.ps1"
del "%TEMP%\medtech-uninstall.ps1" >nul 2>&1
pause
